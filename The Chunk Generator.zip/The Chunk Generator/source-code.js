const canvas_id = document.getElementById("chunk-2d")
const ctx = canvas_id.getContext("2d")
const interact = new Audio("interact.wav")
let deb = false

const general = {

    loopWaitTime : 0,
    reloadstartWaitTime : 400,

}

const canvas = {

    width : 765,
    height : 512,
    backgroundColor : "rgb(149, 221, 255)",

}

function randomToMax(max) {

    return Math.floor(Math.random() * max)

}

const ground = {

    width : 15,
    height : 15,
    xyChanceMax : 5,
    color : "green",
    maxYcounts : 8,
    yCounts : 0,
    x : 0,
    y : 497,
    xyChance : 0,

}

function build_ground () {

    ctx.fillStyle = ground.color
    ctx.fillRect(ground.x,ground.y,ground.width,ground.height)

    ground.xyChance = randomToMax(ground.xyChanceMax)
    ground.x += 15

    if (ground.y < 30) {

        ground.width += 15

    } else {

        ground.height += 15

    }

    if (ground.xyChance < 2) {

        ground.y -= 15

    } else if (ground.xyChance > 3 && ground.yCounts != ground.maxYcounts) {

        ground.y += 15

        ground.yCounts += 1

    } else {

        ground.y = ground.y

    }

}

function loop () {

    setTimeout( function () {

        if (ground.y <= canvas.width) {
            
            build_ground()

            loop()

        }

    },general.loopWaitTime)
    
}

function credits() {

    console.log("The TCH's source-code was made by ry2110.")

}

function reload() {

    if (deb == false) {

        deb = true

        interact.play()

        ground.y = 497
        ground.x = 0
        ground.yCounts = 0
        ground.width = 15
        ground.height = 15
        ground.xyChance = 0
    
        ctx.clearRect(0,0,canvas.width,canvas.height)
    
        loop()

        setTimeout(function () {
            
            deb = false

        },general.reloadstartWaitTime)

    }

}

credits()